<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;//written by me

class StudentController extends Controller
{
    public function index(){
    	// $students = Student::all();
    	$students = Student::paginate(5);
    	return view('welcome',compact('students'));

    }
    public function create(){
    	return view('create');

    }
    public function store(Request $request){
    	$this->validate($request,[
    		'fname' => 'required',
    		'lname' => 'required',
    		'email' => 'required',
    		'phone' => 'required'
    	]);
    	$student = new Student;
    	$student->first_name = $request->fname;
    	$student->last_name = $request->lname;
    	$student->email = $request->email;
    	$student->phone = $request->phone;
    	$student->save();
    	return redirect(route('home'))->with('successMsg','Data inserted successfully');

    }
    public function edit($id)
    {
        $student = Student::find($id);
        return view('edit',compact('student'));
    }
    public function update(Request $request, $id)
    {
    	$this->validate($request,[
    		'fname' => 'required',
    		'lname' => 'required',
    		'email' => 'required',
    		'phone' => 'required'
    	]);
        $student = Student::find($id);
    	$student->first_name = $request->fname;
    	$student->last_name = $request->lname;
    	$student->email = $request->email;
    	$student->phone = $request->phone;
    	$student->save();
    	return redirect(route('home'))->with('successMsg','Data updated successfully');
    }
    public function delete($id){
    	$student = Student::find($id)->delete();
    	return redirect(route('home'))->with('successMsg','Data deleted successfully');
    }
}
