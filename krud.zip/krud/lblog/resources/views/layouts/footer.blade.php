<!-- Footer -->
<footer class="page-footer font-small blue pt-4">

  <!-- Footer Links -->
  
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://www.udemy.com/course/laravel-6-framework/learn/lecture/16352630#overview">Udemy Laravel Course</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->