@extends('layouts.main')
@section('content')


<h1>Edit  Student</h1>
<div class="container">
	@if($errors->any())
	@foreach($errors->all() as $error)
	<div class="alert alert-danger" role="alert">
  		{{ $error }}
	</div>
@endforeach
	@endif
<!-- Default form register -->
<form class="text-center border border-light p-5" action="{{ route('update',$student->id) }}" method="POST">
	{{ csrf_field() }}

    <p class="h4 mb-4">Edit  Student</p>

    <div class="form-row mb-4">
        <div class="col">
            <!-- First name -->
            <input type="text" id="defaultRegisterFormFirstName" name="fname" value="{{ $student->first_name }}" class="form-control" placeholder="First name">
        </div>
        <div class="col">
            <!-- Last name -->
            <input type="text" id="defaultRegisterFormLastName" name="lname" value="{{ $student->last_name }}" class="form-control" placeholder="Last name">
        </div>
    </div>

    <!-- E-mail -->
    <input type="email" id="defaultRegisterFormEmail" name="email" value="{{ $student->email }}" class="form-control mb-4" placeholder="E-mail">

    

    <!-- Phone number -->
    <input type="text" id="defaultRegisterPhonePassword" name="phone" value="{{ $student->phone }}" class="form-control" placeholder="Phone number" aria-describedby="defaultRegisterFormPhoneHelpBlock">
    <!-- <small id="defaultRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">
        Optional - for two step authentication
    </small> -->

    

    <!-- Sign up button -->
    <button class="btn btn-info my-4 btn-block" type="submit">Update</button>

   

</form>
<!-- Default form register -->
</div>
<!-- <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br> -->
@endsection